/* Общая шапка и подвал.
   Перед подключением этого файла на странице задайте:
   window.SITE_ROOT = "."   — для index.html в корне
   window.SITE_ROOT = ".."  — для файлов в /pages/
   window.CURRENT   = "home" | "about" | "services" | "blog" | "contact"
*/
(function(){
  var ROOT = window.SITE_ROOT || ".";
  var CUR  = window.CURRENT || "";

  var links = [
    {id:"home",     label:"Главная",   href: ROOT + "/index.html"},
    {id:"about",    label:"Обо мне",   href: ROOT + "/pages/about.html"},
    {id:"services", label:"Практика",  href: ROOT + "/pages/services.html"},
    {id:"blog",     label:"Блог и видео", href: ROOT + "/pages/blog.html"},
    {id:"contact",  label:"Контакты",  href: ROOT + "/pages/contact.html"}
  ];

  function navHTML(){
    return links.map(function(l){
      var cls = (l.id === CUR) ? ' class="active"' : '';
      return '<a href="'+l.href+'"'+cls+'>'+l.label+'</a>';
    }).join('');
  }

  var headerHTML =
    '<div class="nav">'+
      '<a class="brand" href="'+ROOT+'/index.html" aria-label="Игорь — на главную">'+
        '<span class="monogram">И</span>'+
        '<span class="brand-name">Игорь</span>'+
      '</a>'+
      '<nav class="navlinks" id="navlinks">'+navHTML()+'</nav>'+
      '<a class="nav-cta" href="'+ROOT+'/pages/contact.html">Записаться</a>'+
      '<button class="burger" id="burgerBtn" aria-label="Открыть меню" aria-expanded="false">☰</button>'+
    '</div>';

  var footerHTML =
    '<div class="wrap footer-grid">'+
      '<div class="brand">'+
        '<span class="monogram">И</span>'+
        '<span class="brand-name">Игорь</span>'+
      '</div>'+
      '<div class="footer-links">'+
        '<a href="'+ROOT+'/pages/services.html">Практика</a>'+
        '<a href="'+ROOT+'/pages/blog.html">Блог</a>'+
        '<a href="'+ROOT+'/pages/contact.html">Контакты</a>'+
      '</div>'+
    '</div>'+
    '<div class="wrap copyright">© '+new Date().getFullYear()+' Игорь. Ясность там, где логика не помогает.</div>';

  document.addEventListener("DOMContentLoaded", function(){
    var headerEl = document.querySelector("header.site");
    var footerEl = document.querySelector("footer.site");
    if(headerEl) headerEl.innerHTML = headerHTML;
    if(footerEl) footerEl.innerHTML = footerHTML;

    var burger = document.getElementById("burgerBtn");
    var nav = document.getElementById("navlinks");
    if(burger && nav){
      burger.addEventListener("click", function(){
        var isOpen = nav.classList.toggle("open");
        burger.setAttribute("aria-expanded", isOpen ? "true" : "false");
        burger.textContent = isOpen ? "✕" : "☰";
      });
      nav.querySelectorAll("a").forEach(function(a){
        a.addEventListener("click", function(){
          nav.classList.remove("open");
          burger.setAttribute("aria-expanded","false");
          burger.textContent = "☰";
        });
      });
    }
  });
})();
